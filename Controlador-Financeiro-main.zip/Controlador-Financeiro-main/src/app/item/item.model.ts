export interface Item {
    id: string,
    data: string,
    tipo: string,
    valor: number,
    texto: string ,
    categoria: string
}